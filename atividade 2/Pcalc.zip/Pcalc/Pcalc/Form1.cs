﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double n1, n2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtnumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtnumero2, "");
                n2 = Convert.ToDouble(txtnumero2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtnumero2, "numero 2 invalido");
                txtnumero2.Focus();
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (txtnumero1.Text == "" || txtnumero2.Text == "") { txtresultado.Text = "invalido"; }
            else {
                  resultado = n1 + n2;
                txtresultado.Text = Convert.ToString(resultado);
                  }
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            resultado = n1 - n2;
            txtresultado.Text = Convert.ToString(resultado);
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            resultado = n1 * n2;
            txtresultado.Text = Convert.ToString(resultado);
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (n2 == 0) { txtresultado.Text = "nao se deve dividir por 0"; }
            else { resultado = n1 / n2; txtresultado.Text = Convert.ToString(resultado); }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtresultado.Text = "";
            txtnumero1.Text = "";
            txtnumero2.Text = "";
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("voce deseja sair memsmo?", "saida", MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out n1))
            {
                errorProvider1.SetError(txtnumero1, "Numero invalido");
                txtnumero1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtnumero1, "");
            }
        }
    }
}
