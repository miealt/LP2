﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtlado2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtlado2.Text, out lado2))
            {
                if (txtlado2.Text == "") { errpLado1.Clear(); }
                else
                    errpLado2.SetError(txtlado2, "valor do lado invalido");
            }
            else {errpLado2.Clear();}
        }

        private void txtlado3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtlado3.Text, out lado3)) {
                if (txtlado3.Text == "") { errpLado1.Clear(); }
                else
                    errpLado2.SetError(txtlado3, "valor do lado invalido");}
            else {errpLado3.Clear();}
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtlado1.Text = "";
            txtlado2.Text = "";
            txtlado3.Text = "";
            errpLado3.Clear();
            errpLado2.Clear();
            errpLado1.Clear();
        }

        private void btnfechar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("deseja sair mesmo?", "saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) Close();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            if (txtlado1.Text == string.Empty || txtlado2.Text == string.Empty || txtlado3.Text == string.Empty ) {
                MessageBox.Show("dados nao preenchidos");
            }
            else if (errpLado1.GetError(txtlado1) != "" || errpLado2.GetError(txtlado2) != "" || errpLado3.GetError(txtlado3) != "") { MessageBox.Show("dados invalidos");}
            else if (Math.Abs(lado2 - lado3) < lado1 && lado1 < lado2 + lado3 && Math.Abs(lado1 - lado3) < lado2 && lado2 < lado1 + lado2 && Math.Abs(lado1 - lado2) < lado3 && lado3 < lado1 + lado2) {
                if (lado1 != lado2 && lado2 != lado3 && lado3 != lado1) MessageBox.Show("o triangulo e possivel \n e um triangulo escaleno");
                else if (lado1 == lado2 && lado2 == lado3 && lado3 == lado1) { MessageBox.Show("o triangulo e possivel \n e um triangulo equilatero"); }
                else MessageBox.Show("e um triangulo possivel \n e um triangulo isoceles");
            }
            else MessageBox.Show("triangulo impossivel");

        }

        private void txtlado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtlado1.Text, out lado1)) {
                if (txtlado1.Text == "") { errpLado1.Clear(); }
                else
                    errpLado1.SetError(txtlado1, "valor do lado invlido");
            }
            else { errpLado1.Clear(); }
        }
    }
}
