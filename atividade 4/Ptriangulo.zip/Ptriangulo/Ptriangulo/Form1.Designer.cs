﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtlado1 = new System.Windows.Forms.TextBox();
            this.txtlado3 = new System.Windows.Forms.TextBox();
            this.txtlado2 = new System.Windows.Forms.TextBox();
            this.lblLado1 = new System.Windows.Forms.Label();
            this.lblLado2 = new System.Windows.Forms.Label();
            this.lblLado3 = new System.Windows.Forms.Label();
            this.btnexecutar = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnfechar = new System.Windows.Forms.Button();
            this.errpLado1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errpLado2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errpLado3 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errpLado1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpLado2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpLado3)).BeginInit();
            this.SuspendLayout();
            // 
            // txtlado1
            // 
            this.txtlado1.Location = new System.Drawing.Point(335, 103);
            this.txtlado1.Name = "txtlado1";
            this.txtlado1.Size = new System.Drawing.Size(194, 26);
            this.txtlado1.TabIndex = 0;
            this.txtlado1.Validated += new System.EventHandler(this.txtlado1_Validated);
            // 
            // txtlado3
            // 
            this.txtlado3.Location = new System.Drawing.Point(335, 230);
            this.txtlado3.Name = "txtlado3";
            this.txtlado3.Size = new System.Drawing.Size(194, 26);
            this.txtlado3.TabIndex = 1;
            this.txtlado3.Validated += new System.EventHandler(this.txtlado3_Validated);
            // 
            // txtlado2
            // 
            this.txtlado2.Location = new System.Drawing.Point(335, 166);
            this.txtlado2.Name = "txtlado2";
            this.txtlado2.Size = new System.Drawing.Size(194, 26);
            this.txtlado2.TabIndex = 2;
            this.txtlado2.Validated += new System.EventHandler(this.txtlado2_Validated);
            // 
            // lblLado1
            // 
            this.lblLado1.AutoSize = true;
            this.lblLado1.Location = new System.Drawing.Point(113, 103);
            this.lblLado1.Name = "lblLado1";
            this.lblLado1.Size = new System.Drawing.Size(52, 20);
            this.lblLado1.TabIndex = 3;
            this.lblLado1.Text = "lado 1";
            // 
            // lblLado2
            // 
            this.lblLado2.AutoSize = true;
            this.lblLado2.Location = new System.Drawing.Point(113, 166);
            this.lblLado2.Name = "lblLado2";
            this.lblLado2.Size = new System.Drawing.Size(52, 20);
            this.lblLado2.TabIndex = 4;
            this.lblLado2.Text = "lado 2";
            // 
            // lblLado3
            // 
            this.lblLado3.AutoSize = true;
            this.lblLado3.Location = new System.Drawing.Point(113, 230);
            this.lblLado3.Name = "lblLado3";
            this.lblLado3.Size = new System.Drawing.Size(52, 20);
            this.lblLado3.TabIndex = 5;
            this.lblLado3.Text = "lado 3";
            // 
            // btnexecutar
            // 
            this.btnexecutar.Location = new System.Drawing.Point(81, 324);
            this.btnexecutar.Name = "btnexecutar";
            this.btnexecutar.Size = new System.Drawing.Size(121, 49);
            this.btnexecutar.TabIndex = 6;
            this.btnexecutar.Text = "executar";
            this.btnexecutar.UseVisualStyleBackColor = true;
            this.btnexecutar.Click += new System.EventHandler(this.btnexecutar_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(264, 324);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(121, 49);
            this.btnlimpar.TabIndex = 7;
            this.btnlimpar.Text = "limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnfechar
            // 
            this.btnfechar.Location = new System.Drawing.Point(445, 324);
            this.btnfechar.Name = "btnfechar";
            this.btnfechar.Size = new System.Drawing.Size(121, 49);
            this.btnfechar.TabIndex = 8;
            this.btnfechar.Text = "sair";
            this.btnfechar.UseVisualStyleBackColor = true;
            this.btnfechar.Click += new System.EventHandler(this.btnfechar_Click);
            // 
            // errpLado1
            // 
            this.errpLado1.ContainerControl = this;
            // 
            // errpLado2
            // 
            this.errpLado2.ContainerControl = this;
            // 
            // errpLado3
            // 
            this.errpLado3.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 427);
            this.Controls.Add(this.btnfechar);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnexecutar);
            this.Controls.Add(this.lblLado3);
            this.Controls.Add(this.lblLado2);
            this.Controls.Add(this.lblLado1);
            this.Controls.Add(this.txtlado2);
            this.Controls.Add(this.txtlado3);
            this.Controls.Add(this.txtlado1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errpLado1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpLado2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpLado3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtlado1;
        private System.Windows.Forms.TextBox txtlado3;
        private System.Windows.Forms.TextBox txtlado2;
        private System.Windows.Forms.Label lblLado1;
        private System.Windows.Forms.Label lblLado2;
        private System.Windows.Forms.Label lblLado3;
        private System.Windows.Forms.Button btnexecutar;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnfechar;
        private System.Windows.Forms.ErrorProvider errpLado1;
        private System.Windows.Forms.ErrorProvider errpLado2;
        private System.Windows.Forms.ErrorProvider errpLado3;
    }
}

