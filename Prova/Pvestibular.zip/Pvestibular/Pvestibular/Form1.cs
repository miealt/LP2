﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] vestdados = new int[3,5];
            int totcurso  = 0, tottudo = 0;
            string aux;
            for(int count = 0; count < vestdados.GetLength(0); count++)
            {
                for(int count2 = 0; count2 < vestdados.GetLength(1); count2++)
                {
                    aux = Interaction.InputBox($"quantidade de ingressantes no vestibular do curso {count+1} do ano {count2+1} ", "entrada de dados");
                    if (!int.TryParse(aux, out vestdados[count, count2]))
                    {
                        MessageBox.Show("Entrada invalida");
                        count2--;
                    }
                    else
                    {
                        lstout.Items.Add($"Totl do curso {count+1} do ano {count2 + 1} é de {vestdados[count,count2]}");
                        totcurso += vestdados[count, count2];
                    }
                }
                lstout.Items.Add("______________________________________________________________________________________");
                lstout.Items.Add($"total do curso {count + 1} é de {totcurso}");
                tottudo += totcurso;
                totcurso = 0;
            }
            lstout.Items.Add("______________________________________________________________________________________");
            lstout.Items.Add($"total geral de alunos ingressdos de todos os cursos é de {tottudo}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lstout.Items.Clear();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            if (MessageBox.Show("deseja sair mesmo?", "saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) Close();
        }
    }
}
