﻿namespace Pvestibular
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstout = new System.Windows.Forms.ListBox();
            this.btnexec = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstout
            // 
            this.lstout.FormattingEnabled = true;
            this.lstout.ItemHeight = 20;
            this.lstout.Location = new System.Drawing.Point(12, 12);
            this.lstout.Name = "lstout";
            this.lstout.Size = new System.Drawing.Size(503, 424);
            this.lstout.TabIndex = 0;
            // 
            // btnexec
            // 
            this.btnexec.Location = new System.Drawing.Point(588, 46);
            this.btnexec.Name = "btnexec";
            this.btnexec.Size = new System.Drawing.Size(140, 86);
            this.btnexec.TabIndex = 1;
            this.btnexec.Text = "executar";
            this.btnexec.UseVisualStyleBackColor = true;
            this.btnexec.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(588, 183);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(140, 86);
            this.btnlimpar.TabIndex = 2;
            this.btnlimpar.Text = "limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnexit
            // 
            this.btnexit.Location = new System.Drawing.Point(588, 317);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(140, 86);
            this.btnexit.TabIndex = 3;
            this.btnexit.Text = "sair";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnexec);
            this.Controls.Add(this.lstout);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstout;
        private System.Windows.Forms.Button btnexec;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnexit;
    }
}

