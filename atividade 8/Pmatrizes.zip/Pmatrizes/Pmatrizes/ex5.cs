﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class ex5 : Form
    {
        public ex5()
        {
            InitializeComponent();
        }

        private void btnexec_Click(object sender, EventArgs e)
        {
            int n = 9; //003048251100"9"
            char[] gabarito = { 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D'};
            char[,] respostas = new char[n,10];//lstout.Items.add(o que adicionar);
            for (int count = 0; count< respostas.GetLength(0); count++)
            {
                for(int count2=0; count2 < respostas.GetLength(1); count2++)
                {
                    respostas[count, count2] = Convert.ToChar(Interaction.InputBox($"resposta do aluno{count} do exercicio {count2}", "entrada de dados"));
                }
            }
        }
    }
}
