﻿namespace Pmatrizes
{
    partial class ex4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnexec = new Button();
            rchtxtout = new RichTextBox();
            SuspendLayout();
            // 
            // btnexec
            // 
            btnexec.Location = new Point(434, 130);
            btnexec.Margin = new Padding(2, 2, 2, 2);
            btnexec.Name = "btnexec";
            btnexec.Size = new Size(78, 20);
            btnexec.TabIndex = 0;
            btnexec.Text = "executar";
            btnexec.UseVisualStyleBackColor = true;
            btnexec.Click += btnexec_Click;
            // 
            // rchtxtout
            // 
            rchtxtout.Enabled = false;
            rchtxtout.Location = new Point(36, 28);
            rchtxtout.Margin = new Padding(2, 2, 2, 2);
            rchtxtout.Name = "rchtxtout";
            rchtxtout.Size = new Size(354, 213);
            rchtxtout.TabIndex = 1;
            rchtxtout.Text = "";
            rchtxtout.TextChanged += rchtxtout_TextChanged;
            // 
            // ex4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            Controls.Add(rchtxtout);
            Controls.Add(btnexec);
            Margin = new Padding(2, 2, 2, 2);
            Name = "ex4";
            Text = "ex4";
            ResumeLayout(false);
        }

        #endregion

        private Button btnexec;
        private RichTextBox rchtxtout;
    }
}