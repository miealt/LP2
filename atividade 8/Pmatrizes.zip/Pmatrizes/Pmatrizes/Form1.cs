using Microsoft.VisualBasic;
using System.Collections;
using System.Security.Cryptography.Xml;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("digite um numero", "entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("dados invalidos");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = String.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnex2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            string aux = "";
            string[] nome = { "Ana", "Andr�", "Beatriz", "Camila", "Jo�o", "Joana", "Ot�vio", "Marcelo", "Pedro", "Thais" };
            int count;
            for (count = 0; count < nome.Length; count++)
            {
                nomes.Add(nome[count]);
            }
            nomes.Remove("Ot�vio");
            foreach (string a in nomes)
            {
                aux += a + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnex3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string saida = "";
            string aux = "";
            double media = 0;
            for (int count = 0 ; count < notas.GetLength(0); count++)
            {
                for (int count2 = 0; count2 < notas.GetLength(1); count2++)
                {
                    aux = Interaction.InputBox($"nota{count2} do aluno {count} ", "entrada de dados");
                    if (!double.TryParse(aux, out notas[count, count2]))
                    {
                        MessageBox.Show("Entrada invalida");
                        count2--;
                    }
                    else
                    {
                        media += notas[count, count2];
                    }
                }
                media = media / 3;
                saida = saida + $"M�dia do aluno{count} � : {media}\n";
                media = 0;
            }
            MessageBox.Show(saida);
        }
    }
}
