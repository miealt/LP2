﻿namespace Pmatrizes
{
    partial class ex5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnexec = new Button();
            lstout = new ListBox();
            SuspendLayout();
            // 
            // btnexec
            // 
            btnexec.Location = new Point(573, 186);
            btnexec.Name = "btnexec";
            btnexec.Size = new Size(148, 78);
            btnexec.TabIndex = 1;
            btnexec.Text = "executar";
            btnexec.UseVisualStyleBackColor = true;
            btnexec.Click += btnexec_Click;
            // 
            // lstout
            // 
            lstout.FormattingEnabled = true;
            lstout.Location = new Point(12, 22);
            lstout.Name = "lstout";
            lstout.Size = new Size(532, 404);
            lstout.TabIndex = 2;
            // 
            // ex5
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lstout);
            Controls.Add(btnexec);
            Name = "ex5";
            Text = "ex5";
            ResumeLayout(false);
        }

        #endregion
        private Button btnexec;
        private ListBox lstout;
    }
}