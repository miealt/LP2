﻿namespace Pmatrizes
{
    partial class ex4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnexec = new Button();
            rchtxtout = new RichTextBox();
            SuspendLayout();
            // 
            // btnexec
            // 
            btnexec.Location = new Point(620, 216);
            btnexec.Name = "btnexec";
            btnexec.Size = new Size(112, 34);
            btnexec.TabIndex = 0;
            btnexec.Text = "executar";
            btnexec.UseVisualStyleBackColor = true;
            btnexec.Click += btnexec_Click;
            // 
            // rchtxtout
            // 
            rchtxtout.Enabled = false;
            rchtxtout.Location = new Point(52, 46);
            rchtxtout.Name = "rchtxtout";
            rchtxtout.Size = new Size(504, 353);
            rchtxtout.TabIndex = 1;
            rchtxtout.Text = "";
            // 
            // ex4
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(rchtxtout);
            Controls.Add(btnexec);
            Name = "ex4";
            Text = "ex4";
            ResumeLayout(false);
        }

        #endregion

        private Button btnexec;
        private RichTextBox rchtxtout;
    }
}