﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnex1 = new Button();
            btnex2 = new Button();
            btnex3 = new Button();
            btnex5 = new Button();
            btnex4 = new Button();
            SuspendLayout();
            // 
            // btnex1
            // 
            btnex1.Location = new Point(141, 139);
            btnex1.Name = "btnex1";
            btnex1.Size = new Size(111, 35);
            btnex1.TabIndex = 0;
            btnex1.Text = "ex1";
            btnex1.UseVisualStyleBackColor = true;
            btnex1.Click += button1_Click;
            // 
            // btnex2
            // 
            btnex2.Location = new Point(325, 139);
            btnex2.Name = "btnex2";
            btnex2.Size = new Size(111, 35);
            btnex2.TabIndex = 1;
            btnex2.Text = "ex2";
            btnex2.UseVisualStyleBackColor = true;
            btnex2.Click += btnex2_Click;
            // 
            // btnex3
            // 
            btnex3.Location = new Point(500, 139);
            btnex3.Name = "btnex3";
            btnex3.Size = new Size(111, 35);
            btnex3.TabIndex = 2;
            btnex3.Text = "ex3";
            btnex3.UseVisualStyleBackColor = true;
            btnex3.Click += btnex3_Click;
            // 
            // btnex5
            // 
            btnex5.Location = new Point(405, 265);
            btnex5.Name = "btnex5";
            btnex5.Size = new Size(112, 34);
            btnex5.TabIndex = 3;
            btnex5.Text = "ex5";
            btnex5.UseVisualStyleBackColor = true;
            btnex5.Click += btnex5_Click;
            // 
            // btnex4
            // 
            btnex4.Location = new Point(242, 265);
            btnex4.Name = "btnex4";
            btnex4.Size = new Size(112, 34);
            btnex4.TabIndex = 4;
            btnex4.Text = "ex4";
            btnex4.UseVisualStyleBackColor = true;
            btnex4.Click += btnex4_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(799, 451);
            Controls.Add(btnex4);
            Controls.Add(btnex5);
            Controls.Add(btnex3);
            Controls.Add(btnex2);
            Controls.Add(btnex1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnex1;
        private Button btnex2;
        private Button btnex3;
        private Button btnex5;
        private Button btnex4;
    }
}
