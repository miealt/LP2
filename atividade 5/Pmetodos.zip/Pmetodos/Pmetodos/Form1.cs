namespace Pmetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmex2>().Count() > 0)
            {
                Application.OpenForms["frmex2"].BringToFront();
            }
            else
            {
                frmex2 obj2 = new frmex2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmex3>().Count() > 0)
            {
                Application.OpenForms["frmex3"].BringToFront();
            }
            else
            {
                frmex3 obj3 = new frmex3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmex4>().Count() > 0)
            {
                Application.OpenForms["frmex4"].BringToFront();
            }
            else
            {
                frmex4 obj4 = new frmex4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmex5>().Count() > 0)
            {
                Application.OpenForms["frmex5"].BringToFront();
            }
            else
            {
                frmex5 obj5 = new frmex5();
                obj5.MdiParent = this;
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
