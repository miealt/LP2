﻿namespace Pmetodos
{
    partial class frmex5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            mkstxtn1 = new MaskedTextBox();
            mkstxtn2 = new MaskedTextBox();
            btnsortear = new Button();
            SuspendLayout();
            // 
            // mkstxtn1
            // 
            mkstxtn1.Location = new Point(208, 160);
            mkstxtn1.Mask = "00000000000";
            mkstxtn1.Name = "mkstxtn1";
            mkstxtn1.Size = new Size(100, 23);
            mkstxtn1.TabIndex = 0;
            // 
            // mkstxtn2
            // 
            mkstxtn2.Location = new Point(472, 160);
            mkstxtn2.Mask = "0000000000";
            mkstxtn2.Name = "mkstxtn2";
            mkstxtn2.Size = new Size(100, 23);
            mkstxtn2.TabIndex = 1;
            // 
            // btnsortear
            // 
            btnsortear.Location = new Point(341, 302);
            btnsortear.Name = "btnsortear";
            btnsortear.Size = new Size(101, 42);
            btnsortear.TabIndex = 2;
            btnsortear.Text = "SORTEAR";
            btnsortear.UseVisualStyleBackColor = true;
            btnsortear.Click += btnsortear_Click;
            // 
            // frmex5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnsortear);
            Controls.Add(mkstxtn2);
            Controls.Add(mkstxtn1);
            Name = "frmex5";
            Text = "frmex5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox mkstxtn1;
        private MaskedTextBox mkstxtn2;
        private Button btnsortear;
    }
}