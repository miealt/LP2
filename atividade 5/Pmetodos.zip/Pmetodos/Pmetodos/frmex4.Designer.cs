﻿namespace Pmetodos
{
    partial class frmex4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btncnumber = new Button();
            btn1stblank = new Button();
            btncalfabetos = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(140, 58);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(498, 213);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btncnumber
            // 
            btncnumber.Location = new Point(149, 324);
            btncnumber.Name = "btncnumber";
            btncnumber.Size = new Size(98, 60);
            btncnumber.TabIndex = 1;
            btncnumber.Text = "contar numeros";
            btncnumber.UseVisualStyleBackColor = true;
            btncnumber.Click += btncnumber_Click;
            // 
            // btn1stblank
            // 
            btn1stblank.Location = new Point(334, 324);
            btn1stblank.Name = "btn1stblank";
            btn1stblank.Size = new Size(98, 60);
            btn1stblank.TabIndex = 2;
            btn1stblank.Text = "achar o primeiro epaço em branco";
            btn1stblank.UseVisualStyleBackColor = true;
            btn1stblank.Click += btn1stblank_Click;
            // 
            // btncalfabetos
            // 
            btncalfabetos.Location = new Point(541, 324);
            btncalfabetos.Name = "btncalfabetos";
            btncalfabetos.Size = new Size(98, 60);
            btncalfabetos.TabIndex = 3;
            btncalfabetos.Text = "contar numero de alfabetos";
            btncalfabetos.UseVisualStyleBackColor = true;
            btncalfabetos.Click += btncalfabetos_Click;
            // 
            // frmex4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btncalfabetos);
            Controls.Add(btn1stblank);
            Controls.Add(btncnumber);
            Controls.Add(rchtxtFrase);
            Name = "frmex4";
            Text = "frmex4";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btncnumber;
        private Button btn1stblank;
        private Button btncalfabetos;
    }
}