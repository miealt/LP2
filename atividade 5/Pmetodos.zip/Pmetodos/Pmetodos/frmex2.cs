﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmex2 : Form
    {
        public frmex2()
        {
            InitializeComponent();
        }

        private void btninsert1_Click(object sender, EventArgs e)
        {
            txtpalavra2.Text = txtpalavra2.Text.Substring(0, txtpalavra2.Text.Length / 2) + txtpalavra1.Text + txtpalavra2.Text.Substring(txtpalavra2.Text.Length / 2);
        }

        private void btnsinsertdp_Click(object sender, EventArgs e)
        {
            txtpalavra2.Text = txtpalavra1.Text.Insert(txtpalavra1.Text.Length / 2, "**");
        }
    }
}
