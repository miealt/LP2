﻿namespace Pmetodos
{
    partial class frmex2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtpalavra2 = new TextBox();
            txtpalavra1 = new TextBox();
            btninsert1 = new Button();
            btnsinsertdp = new Button();
            SuspendLayout();
            // 
            // txtpalavra2
            // 
            txtpalavra2.Location = new Point(36, 188);
            txtpalavra2.Name = "txtpalavra2";
            txtpalavra2.Size = new Size(717, 23);
            txtpalavra2.TabIndex = 0;
            // 
            // txtpalavra1
            // 
            txtpalavra1.Location = new Point(36, 69);
            txtpalavra1.Name = "txtpalavra1";
            txtpalavra1.Size = new Size(717, 23);
            txtpalavra1.TabIndex = 1;
            // 
            // btninsert1
            // 
            btninsert1.Location = new Point(138, 335);
            btninsert1.Name = "btninsert1";
            btninsert1.Size = new Size(100, 38);
            btninsert1.TabIndex = 2;
            btninsert1.Text = "insert 1 in mid of 2";
            btninsert1.UseVisualStyleBackColor = true;
            btninsert1.Click += btninsert1_Click;
            // 
            // btnsinsertdp
            // 
            btnsinsertdp.Location = new Point(523, 335);
            btnsinsertdp.Name = "btnsinsertdp";
            btnsinsertdp.Size = new Size(100, 38);
            btnsinsertdp.TabIndex = 3;
            btnsinsertdp.Text = "insert ** to txt2";
            btnsinsertdp.UseVisualStyleBackColor = true;
            btnsinsertdp.Click += btnsinsertdp_Click;
            // 
            // frmex2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnsinsertdp);
            Controls.Add(btninsert1);
            Controls.Add(txtpalavra1);
            Controls.Add(txtpalavra2);
            Name = "frmex2";
            Text = "frmex2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtpalavra2;
        private TextBox txtpalavra1;
        private Button btninsert1;
        private Button btnsinsertdp;
    }
}