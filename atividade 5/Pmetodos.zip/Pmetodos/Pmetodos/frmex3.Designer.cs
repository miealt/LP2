﻿namespace Pmetodos
{
    partial class frmex3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btninvert = new Button();
            btnrm1do2 = new Button();
            txtpalavra2 = new TextBox();
            txtpalavra1 = new TextBox();
            SuspendLayout();
            // 
            // btninvert
            // 
            btninvert.Location = new Point(443, 305);
            btninvert.Name = "btninvert";
            btninvert.Size = new Size(136, 63);
            btninvert.TabIndex = 8;
            btninvert.Text = "inverter txt2";
            btninvert.UseVisualStyleBackColor = true;
            btninvert.Click += btninvert_Click;
            // 
            // btnrm1do2
            // 
            btnrm1do2.Location = new Point(214, 305);
            btnrm1do2.Name = "btnrm1do2";
            btnrm1do2.Size = new Size(136, 63);
            btnrm1do2.TabIndex = 7;
            btnrm1do2.Text = "remover do 2 o que esta no 3";
            btnrm1do2.UseVisualStyleBackColor = true;
            btnrm1do2.Click += btnrm1do2_Click;
            // 
            // txtpalavra2
            // 
            txtpalavra2.Location = new Point(149, 179);
            txtpalavra2.Name = "txtpalavra2";
            txtpalavra2.Size = new Size(503, 23);
            txtpalavra2.TabIndex = 6;
            // 
            // txtpalavra1
            // 
            txtpalavra1.Location = new Point(149, 82);
            txtpalavra1.Name = "txtpalavra1";
            txtpalavra1.Size = new Size(503, 23);
            txtpalavra1.TabIndex = 5;
            // 
            // frmex3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btninvert);
            Controls.Add(btnrm1do2);
            Controls.Add(txtpalavra2);
            Controls.Add(txtpalavra1);
            Name = "frmex3";
            Text = "frmex3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btninvert;
        private Button btnrm1do2;
        private TextBox txtpalavra2;
        private TextBox txtpalavra1;
    }
}