﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmex4 : Form
    {
        public frmex4()
        {
            InitializeComponent();
        }

        private void btncalfabetos_Click(object sender, EventArgs e)
        {
            int contaLetras = 0;
            foreach (var c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetras++;
                }
            }
            MessageBox.Show($"O texto tem {contaLetras} letras.");
        }

        private void btncnumber_Click(object sender, EventArgs e)
        {
            int comprimento = rchtxtFrase.Text.Length;
            int contador = 0;
            int contaNum = 0;
            while (contador < comprimento)
            {
                if (Char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contaNum++;
                }
                contador++;
            }
            MessageBox.Show($"O texto tem {contaNum} números.");

        }

        private void btn1stblank_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do 1º caracter em branco é: {i + 1}");
                    break;
                }
            }
        }
    }
}
