﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmex5 : Form
    {
        public frmex5()
        {
            InitializeComponent();
        }

        private void btnsortear_Click(object sender, EventArgs e)
        {
            int min, max;
            if (!int.TryParse(mkstxtn1.Text, out min) || (!int.TryParse(mkstxtn2.Text, out max)) || (min <= max))
            {
                MessageBox.Show("dados invalidos.");
            }
            else
            {
                Random obj1 = new Random();
                int sorteado = obj1.Next(min, max);
                MessageBox.Show($"numero sorteado : {sorteado}");
            }
        }
    }
}
