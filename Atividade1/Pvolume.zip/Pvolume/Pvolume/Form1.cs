namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume; //var global 
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtRaio.Text, out raio) || raio <= 0) && txtRaio.Text != "")
            {
                MessageBox.Show("RAIO inv�lido.");
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtAltura.Text, out altura) || altura <= 0) && txtAltura.Text != "")
            {
                MessageBox.Show("ALTURA inv�lido.");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || raio <= 0)
            {
                MessageBox.Show("RAIO inv�lido.");
                txtRaio.Focus();
            }
            else if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("ALTURA inv�lido.");
                txtAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = "";
            txtVolume.Text = "";
        }
    }
}
